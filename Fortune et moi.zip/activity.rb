
####
# fix: rename to singular - ActivityDb::Model

Activity = ActivityDb::Models::Activity

