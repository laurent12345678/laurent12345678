
Badge = SportDb::Model::Badge

