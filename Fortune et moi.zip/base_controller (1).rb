
class Setup::BaseController < ApplicationController
  
  layout 'setup'

  ## todo: add require_admin etc.  
  
end
