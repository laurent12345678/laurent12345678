
class Admin::BaseController < ApplicationController
  
  layout 'admin'

  ## todo: add require_admin etc.  
  
end
