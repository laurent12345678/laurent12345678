
City = WorldDb::Model::City

