
Continent = WorldDb::Model::Continent
