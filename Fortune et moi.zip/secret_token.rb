# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Sportbook::Application.config.secret_token = '401b16155e61e58734017af93b950ba094a8b79c5b90c6c1f5db97d49b2ec09e1a142e6b605cd74ba62b6db3f9465ce3a28db2b9a91a6a378e37c0588cdda4b0'
