
SportDb.read_setup( 'setups/all', find_data_path_from_gemfile_gitref('american-football.db'))
