

Tagging = TagDb::Model::Tagging
